var sterm;
var panel;
$(document).ready(function() {
	$("button").click(function() {
		sterm = $('input[name="q"]').val();
		panel = $('#sonuc');
		start();
		var int = self.setInterval(function() {
			start();
		}, 10000);

	});
});

function start() {
	
	$.ajax({
		type : 'GET',
		dataType : 'jsonp',
		url : 'http://search.twitter.com/search.json',
		data : {
			q : sterm,
			rpp : 5

		},
		success : function(data) {
			panel.empty();
			$.each(data.results, function(index, tweet) {
				//alert(tweet.text);
				
				var created = tweet.created_at;
				var text = tweet.text;
				var name = tweet.from_user_name;
				var nic = tweet.from_user;
				var img = tweet.profile_image_url;

				var tweetHtml = '<div class="tweet"><img src="' + img + '" /><div><b>' + name + "</b> @" + nic + " <b>(" + created + ')</b></div><div style="font-size:11px;">' + text + '</div> </div>';
				panel.append(tweetHtml);
			});
		}
	});

}
